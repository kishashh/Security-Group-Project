# Security-Group-Project
###### Chris Dalton, Cole Dalton, Blake Reynolds, and Matt Kish
### HOW TO RUN

Run the webdeploy.py file, and ctrl + click the IP, and it should open the browser. If this doesn't work, your build is incorrect.

### Installation
The following are the needed installations for the facial recognitions portion of the program.
1. Opencv
```bash
pip3 install opencv-contrib-python
```
2. Flask
```bash
pip3 install flask
```
